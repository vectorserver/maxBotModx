<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '<b>Версия 0.0.1-v</b><br>
Автор: <a href="https://t.me/vectorserver" target="_blank">@vectorserver</a><br>
- Начальная сборка пакета MAX API.',
    'readme' => 'Этот пакет предназначен для интеграции с MAX API.<br>
Включает системные настройки для бота и структуру папок в core и assets.',
    'license' => 'Распространяется "как есть". Все права принадлежат автору.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'dfede627a6d018175778229a3739312f',
      'native_key' => 'max',
      'filename' => 'modNamespace/d8cdc27db80c43ee269da36465a51109.vehicle',
      'namespace' => 'max',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9588f8130af073016105f1af44a649f',
      'native_key' => 'bot_subscribe_url',
      'filename' => 'modSystemSetting/0af2f081cd88f10c7b3a97b6c1644206.vehicle',
      'namespace' => 'max',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5626636252e518b330a426d8b0560562',
      'native_key' => 'max_bot_admins',
      'filename' => 'modSystemSetting/92e6cde306bcee9acc284de8114c02aa.vehicle',
      'namespace' => 'max',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0c63b75a5c4f45689d3bed8ab4dd2f8',
      'native_key' => 'max_bot_name',
      'filename' => 'modSystemSetting/86ee75e8073b91bf7afd56fb825a8bfb.vehicle',
      'namespace' => 'max',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b56b05cbecf4b489eaba5cec4fb64e9a',
      'native_key' => 'max_bot_token',
      'filename' => 'modSystemSetting/43b63f3ba8ecd7747822ab25f89b51cd.vehicle',
      'namespace' => 'max',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0688ea8725906de37a47412a08caca20',
      'native_key' => 1,
      'filename' => 'modCategory/c1ededed0e2875f981fda969d6d67188.vehicle',
      'namespace' => 'max',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'c4386598b1394c47bc7fb6c652d985a1',
      'native_key' => 'c4386598b1394c47bc7fb6c652d985a1',
      'filename' => 'xPDOFileVehicle/5c2e0026af5141603cbcd7ee3ec6ad2d.vehicle',
      'namespace' => 'max',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'b535c72c203cf76586bcc924dd56c28c',
      'native_key' => 'b535c72c203cf76586bcc924dd56c28c',
      'filename' => 'xPDOFileVehicle/830faf110772ba7b9701e361fec4b5f6.vehicle',
      'namespace' => 'max',
    ),
  ),
);