<?php 
array (
  'timestamp' => 1775030719158,
  'message' => 
  array (
    'recipient' => 
    array (
      'chat_id' => 244701880,
      'chat_type' => 'dialog',
      'user_id' => 216590608,
    ),
    'timestamp' => 1775030719158,
    'body' => 
    array (
      'mid' => 'mid.000000000e95dab8019d481352b64fb0',
      'seq' => 116328413210759088,
      'text' => '/dell',
    ),
    'sender' => 
    array (
      'user_id' => 41759656,
      'first_name' => 'Степан',
      'last_name' => '',
      'is_bot' => false,
      'last_activity_time' => 1775030719000,
      'name' => 'Степан',
    ),
  ),
  'user_locale' => 'ru',
  'update_type' => 'message_created',
);