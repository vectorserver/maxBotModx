<?php 
array (
  'timestamp' => 1776143422393,
  'chat_id' => 177084685,
  'user' => 
  array (
    'user_id' => 107409437,
    'first_name' => 'Колумбийский',
    'last_name' => 'Наркобарон',
    'is_bot' => false,
    'last_activity_time' => 0,
    'description' => 'Я тут https://t.me/vectorserver
Это технический аккаунт, Можете не писать мне сюда ответа не будет!',
    'avatar_url' => 'https://i.oneme.ru/i?r=BTFjO43w8Yr1OSJ4tcurq5HizuMUkIESquU7hv7HAcf1dNmm2WFDKpgc8P-d42dqsjQ',
    'full_avatar_url' => 'https://i.oneme.ru/i?r=BTFjO43w8Yr1OSJ4tcurq5HibrFji7yn_GU9BDU5RaZ-kdmm2WFDKpgc8P-d42dqsjQ',
    'name' => 'Колумбийский Наркобарон',
  ),
  'user_locale' => 'ru',
  'user_id' => 107409437,
  'update_type' => 'bot_started',
);