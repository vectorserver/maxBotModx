<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '<b>Версия 0.0.1-v</b><br>
Автор: <a href="https://t.me/vectorserver" target="_blank">@vectorserver</a><br>
- Начальная сборка пакета MAX API.',
    'readme' => 'Этот пакет предназначен для интеграции с MAX API.<br>
Включает системные настройки для бота и структуру папок в core и assets.',
    'license' => 'Распространяется "как есть". Все права принадлежат автору.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '25cdefb2ef70232990aa6a98136e6bf9',
      'native_key' => 'max',
      'filename' => 'modNamespace/1ed98e3598c1f4fdc056101556ee2196.vehicle',
      'namespace' => 'max',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10dce479f696fe8a535bde37fb6288cd',
      'native_key' => 'bot_subscribe_url',
      'filename' => 'modSystemSetting/605ea9e78078dbd98f9937d1ab081960.vehicle',
      'namespace' => 'max',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01a98f1021db0a002d90b5b70423d716',
      'native_key' => 'max_bot_admins',
      'filename' => 'modSystemSetting/b2f8b343ba072ee4c842d70e86c5d625.vehicle',
      'namespace' => 'max',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80638e3d7b2debced60ac309e8310186',
      'native_key' => 'max_bot_name',
      'filename' => 'modSystemSetting/544f1810129d817f0227033ccb817ed0.vehicle',
      'namespace' => 'max',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f3272051d8a1bf7c55cd20a3a4a5baa',
      'native_key' => 'max_bot_token',
      'filename' => 'modSystemSetting/833f0d062dedf33e020b4439bc489cda.vehicle',
      'namespace' => 'max',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f72c6968415c9d9c7b9e3cbb04ed7a25',
      'native_key' => 1,
      'filename' => 'modCategory/b96c107f2b4dda8c4a3bdc7efb081717.vehicle',
      'namespace' => 'max',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'cbbb1d10df086338355fec22f6cd0078',
      'native_key' => 'cbbb1d10df086338355fec22f6cd0078',
      'filename' => 'xPDOFileVehicle/c9d6c637bdc12cb572f2892fbda87cae.vehicle',
      'namespace' => 'max',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '13884d0be7de1e4c0c2f80e78c785628',
      'native_key' => '13884d0be7de1e4c0c2f80e78c785628',
      'filename' => 'xPDOFileVehicle/ab4b7e5e17078c7b984b351acff82886.vehicle',
      'namespace' => 'max',
    ),
  ),
);